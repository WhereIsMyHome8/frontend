export default {
  USER_ADD: "userAdd",
  ALL_USER: "userAll",
  USER_LOGIN: "userLogin",
  ADD_COMMENT: "add_comment",
  QNA_DELETE: "qna_delete",
  QNA_ADD: "qna_add",
  SELECT_QNA: "select_qna",
  SELECT_COMMMENT: "select_comment",
};
